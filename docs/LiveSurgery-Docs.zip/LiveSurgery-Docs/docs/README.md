## LiveSurgery — Software Architecture & Documentation Pack

LiveSurgery is a **simulated Operating Room (OR) “workspace”** web experience built as a **frontend-only PoC** today, designed to evolve into an **MVP with real-time streaming, collaboration, auth, and persistence**, and later into a production-grade MedTech-adjacent system.

> **Disclaimer:** The PoC is **not for clinical use**. The MVP and Production paths described here are architectural targets, not claims of existing capability.

### What exists today (NOW — PoC)
- React + Tailwind (Vite) UI deployed on Vercel
- Multi-panel OR “workspace” layout with **HTML5 video assets**
- Source selector sidebar
- Drag-and-drop + resize/re-layout controls (simulated)
- Simulated roles/personas for storytelling (Surgeon / Observer / Admin)
- No backend, no auth, no persistence, no WebRTC

### What’s next (NEXT — MVP)
- Real-time video streaming + multi-user sessions (SFU-based)
- Authentication + RBAC, invitation links
- Persistent session metadata, layouts, and simple archives
- Real-time collaboration state (layout/source changes, basic annotations)

### Future (Production)
- Compliance hardening (GDPR posture → regulated workflows)
- Enterprise deployment & governance, audit-grade trails
- Interoperability layer (device ingest, hospital IT integration)
- Stronger data classification and retention controls

---

## Run locally (PoC)
```bash
# install
npm install

# run dev server
npm run dev

# build
npm run build

# preview
npm run preview
```

## Demo
- Live demo: `<ADD_VERCEL_URL_HERE>`

---

## Repository structure (suggested)
```txt
/
  src/
    app/                 # shell, routing, providers
    components/          # reusable UI components
    features/
      workspace/         # multi-panel OR workspace (PoC core)
      video/             # video asset + source selection
      roles/             # simulated personas and UI gating
    styles/
    assets/              # video files, thumbnails (PoC)
  docs/                  # this documentation pack
  public/
```

---

## Roadmap snapshot
| Phase | Outcome | Notes |
|---|---|---|
| NOW (PoC) | UI-only simulated OR workspace | Portfolio-ready demo of interaction design |
| NEXT (MVP) | Real-time sessions + auth + persistence | Single-developer-friendly with managed services |
| FUTURE | Compliance & enterprise readiness | Auditability, security, device interoperability |
