# ADR 002: MVP Authentication & RBAC

## Status
Accepted

## Context
MVP requires multi-user sessions and safe access controls (even for non-clinical demos). PoC roles are simulated and not secure.

## Decision
Implement **real authentication** and **RBAC**:
- Roles: Surgeon / Observer / Admin
- Enforce on API + realtime operations
- Use short-lived tokens for WS and SFU access

## Consequences
- ✅ Enables collaboration and prevents casual abuse
- ✅ Sets foundation for audit and compliance posture
- ❌ Adds backend complexity and secret management
