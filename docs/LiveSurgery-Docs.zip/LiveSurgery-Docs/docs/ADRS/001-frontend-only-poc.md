# ADR 001: Frontend-only PoC

## Status
Accepted

## Context
LiveSurgery currently exists as a portfolio-grade interactive UI demonstrating an OR workspace with simulated roles and HTML5 video assets. There is no backend.

## Decision
Maintain a **frontend-only PoC** deployed on Vercel, with simulated personas and static assets.

## Consequences
- ✅ Fast iteration, low cost, easy demos
- ✅ Clear separation between demo UI and production claims
- ❌ No persistence/auth/realtime beyond simulation
