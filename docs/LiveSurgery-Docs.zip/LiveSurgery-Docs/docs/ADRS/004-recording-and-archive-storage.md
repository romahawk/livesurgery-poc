# ADR 004: Recording & Archive Storage

## Status
Accepted (MVP-lite)

## Context
A portfolio-realistic system benefits from recording and replay. Media data is large and not suited for primary DB storage.

## Decision
Store recordings in **object storage** (S3-compatible).
- Metadata in Postgres (`archives` table)
- Playback via HLS or MP4
- Retention via `expires_at`

## Consequences
- ✅ Simple scaling and cost model
- ✅ Clear separation of metadata vs blobs
- ❌ Requires lifecycle policies and access control to objects
