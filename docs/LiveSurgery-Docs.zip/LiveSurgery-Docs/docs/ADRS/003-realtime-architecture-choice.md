# ADR 003: Realtime Media Architecture Choice

## Status
Accepted (MVP), revisit for Production

## Context
Multi-party low-latency video streaming requires a scalable architecture. Mesh P2P does not scale beyond small groups reliably.

## Decision
Use an **SFU-based architecture** for MVP.
- Preferred: LiveKit (managed first, self-host later)
- Alternative: mediasoup (future, more custom work)

## Consequences
- ✅ Scales to multiple observers
- ✅ Better control over QoS and bandwidth
- ❌ Requires TURN planning and token/security model
