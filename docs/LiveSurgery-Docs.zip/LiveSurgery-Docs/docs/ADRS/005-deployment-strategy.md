# ADR 005: Deployment Strategy

## Status
Accepted

## Context
The PoC is already deployed on Vercel. The MVP introduces backend + realtime media services that may not fit purely static hosting.

## Decision
Adopt a staged deployment approach:
- **NOW:** Vercel static hosting for SPA
- **NEXT:** Vercel + managed DB/storage + managed SFU
- **FUTURE:** containerized portability (self-host SFU/TURN, multi-region)

## Consequences
- ✅ Fast MVP delivery without heavy ops
- ✅ Clear evolution path for production credibility
- ❌ Some vendor coupling in MVP phase
