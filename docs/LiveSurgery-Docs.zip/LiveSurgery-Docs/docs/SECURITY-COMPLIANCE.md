## High-level threat model

### Primary risks (MVP)
- Unauthorized access to sessions/streams (broken authz)
- Token leakage (SFU tokens, WS tokens)
- Session hijacking (replay tokens, weak expiration)
- Sensitive metadata exposure (participant identity, session titles)
- Supply chain issues (dependencies)

### Mitigations (MVP baseline)
- Short-lived tokens; rotate on join/reconnect
- RBAC checks on every sensitive operation
- Secure-by-default CORS, CSP, and cookie settings
- Encrypt at rest (DB + object storage) and in transit (TLS)
- Structured audit logs for membership/role changes

---

## AuthN/AuthZ model

### NOW (PoC)
- Simulated roles via UI toggle only

### NEXT (MVP)
- Real identity (OIDC or similar)
- RBAC:
  - **Surgeon:** create/start/end session, publish streams, edit layout
  - **Observer:** view/subscribe, limited layout interactions
  - **Admin:** manage users/roles, retention defaults, visibility

### FUTURE (Production)
- Org-based tenancy, SCIM/SSO
- Fine-grained permissions (capabilities per session)

---

## Data protection / GDPR posture (MVP)
- Minimize personal data: store only what is needed for login + audit trail
- Separate “demo content” from any user-generated content
- Define retention for archives (`expires_at`)
- Provide deletion pathway (admin tool) for user and session artifacts
- Document data flows and subprocessors (if managed SFU/storage used)

---

## Logging & auditing approach
- Audit events (append-only) for:
  - session created/started/ended
  - participant joined/left
  - role changes
  - recording start/stop
  - archive access

---

## Clinical-use disclaimer (explicit)
- **PoC and MVP are not validated medical devices**
- No clinical claims, no patient data handling
- For clinical use: requires QMS, risk management, validation, and regulatory pathway
