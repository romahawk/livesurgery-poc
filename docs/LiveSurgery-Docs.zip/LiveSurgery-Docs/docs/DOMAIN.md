## Domain model & terminology

### Core terms
- **Session:** A live (or replayable) collaborative event with participants and media streams.
- **Stream Source:** A media input published into a session (camera, screen, ingest).
- **Layout:** Spatial arrangement of panels and assigned sources.
- **Participant:** A user present in a session with a role and capabilities.
- **Role:** Permission profile (Surgeon / Observer / Admin).
- **Annotation:** Lightweight shared markup (cursor, marker, region) over the workspace.
- **Archive Item:** A stored recording and metadata for later playback.

---

## Entities & constraints (MVP)

### `User`
- unique email / identity-provider subject
- roles may be global (admin) + per-session role override

### `Session`
- has owner (surgeon/admin)
- lifecycle: `DRAFT` → `LIVE` → `ENDED` → `ARCHIVED` (optional)

### `Participant`
- belongs to session + user
- role within session: `SURGEON | OBSERVER | ADMIN`
- presence state: `JOINED | LEFT`

### `Stream`
- belongs to session
- published by a participant (or service account)
- type: `CAMERA | SCREEN | INGEST`
- SFU track identifiers stored as references

### `Layout`
- belongs to session
- versioned snapshots recommended (`layout_version` int)
- stored as JSON with panel geometry + assigned stream ids

### `Annotation`
- belongs to session
- ephemeral by default; persist only if needed for replay

### `ArchiveItem`
- belongs to session
- storage: object storage URL(s) + format metadata
- retention: expires_at optional

---

## Suggested DB schema (MVP)
> Keep schema compact; expand later.

```sql
-- users
create table users (
  id uuid primary key,
  email text unique,
  display_name text,
  idp_subject text unique,
  created_at timestamptz not null default now()
);

-- sessions
create table sessions (
  id uuid primary key,
  title text not null,
  status text not null check (status in ('DRAFT','LIVE','ENDED','ARCHIVED')),
  created_by uuid not null references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- session_participants
create table session_participants (
  session_id uuid references sessions(id),
  user_id uuid references users(id),
  role text not null check (role in ('SURGEON','OBSERVER','ADMIN')),
  joined_at timestamptz,
  left_at timestamptz,
  primary key (session_id, user_id)
);

-- streams (metadata only; SFU owns media)
create table streams (
  id uuid primary key,
  session_id uuid not null references sessions(id),
  published_by uuid references users(id),
  kind text not null check (kind in ('CAMERA','SCREEN','INGEST')),
  sfu_room text not null,
  sfu_track_ref text not null,
  created_at timestamptz not null default now()
);

-- layouts (versioned)
create table session_layouts (
  session_id uuid references sessions(id),
  version int not null,
  layout_json jsonb not null,
  updated_by uuid references users(id),
  updated_at timestamptz not null default now(),
  primary key (session_id, version)
);

-- archives
create table archives (
  id uuid primary key,
  session_id uuid not null references sessions(id),
  storage_key text not null,
  playback_type text not null check (playback_type in ('MP4','HLS')),
  duration_seconds int,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);
```
