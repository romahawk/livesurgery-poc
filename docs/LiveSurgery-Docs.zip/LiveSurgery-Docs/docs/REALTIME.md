## Realtime approach comparison

### SFU vs MCU
| Approach | How it works | Pros | Cons | Fit |
|---|---|---|---|---|
| SFU | Clients send one uplink; SFU forwards to others | Low latency, scalable, client chooses quality layers | Clients must decode multiple streams | Best default for MVP |
| MCU | Server mixes into one stream | Simple for clients | Higher server cost/latency, complex mixing | Better for niche cases |

---

## Signaling, TURN/STUN
- Use SFU-provided signaling where possible (token-based join)
- TURN required for restrictive NAT/firewalls; include in deployment plan

---

## Proposed MVP approach (recommended)
### MVP choice: **Managed SFU (LiveKit Cloud) OR self-host LiveKit**
- **Why:** reduces custom signaling burden; accelerates “real streaming” delivery
- **Later:** migrate to self-host, multi-region, deeper QoS controls

---

## Sequences (Mermaid)

### Join session (auth + realtime + media tokens)
```mermaid
sequenceDiagram
  participant U as User (Browser)
  participant FE as Frontend SPA
  participant API as Session API
  participant WS as Realtime Gateway
  participant SFU as SFU

  U->>FE: Open session link
  FE->>API: POST /participants:join (Bearer/JWT)
  API-->>FE: wsUrl+wsToken, sfuUrl+sfuToken, role
  FE->>WS: Connect (wsToken)
  WS-->>FE: presence sync
  FE->>SFU: Connect (sfuToken)
  SFU-->>FE: subscribed tracks
```

### Publish stream
```mermaid
sequenceDiagram
  participant FE as Publisher (Browser)
  participant SFU as SFU
  participant API as API

  FE->>API: Request publish token (optional)
  API-->>FE: sfuToken
  FE->>FE: getUserMedia()
  FE->>SFU: Publish tracks (WebRTC)
  SFU-->>FE: publish ack
```

### Subscribe stream
```mermaid
sequenceDiagram
  participant FE as Observer (Browser)
  participant SFU as SFU

  FE->>SFU: Join room
  SFU-->>FE: Track list + metadata
  FE->>SFU: Subscribe selected tracks
  SFU-->>FE: RTP media flows
```

### Start/stop recording
```mermaid
sequenceDiagram
  participant Admin as Admin/Surgeon
  participant API as API
  participant SFU as SFU
  participant REC as Recording Worker
  participant OBJ as Object Storage

  Admin->>API: POST /archives {mode: RECORD_LIVE}
  API->>SFU: Start recording (provider-specific)
  SFU->>REC: Stream media to recorder
  REC->>OBJ: Write segments/MP4
  REC-->>API: Recording completed + metadata
  API-->>Admin: Archive ready
```

---

## Archive fallback (HLS)
- For replay: store HLS (segments + manifest) or MP4 in object storage
- Frontend playback uses standard HTML5 player for archive
