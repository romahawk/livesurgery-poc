## Architecture principles & constraints

### Principles
- **Transparency:** clearly separate *simulated PoC* from *real MVP capabilities*
- **Incremental evolution:** PoC → MVP should reuse UI primitives and interaction patterns
- **Production-realistic:** choose proven building blocks for real-time media + identity
- **Operationally simple:** optimized for a solo developer path; scale later
- **Security-first baseline:** least privilege, secure defaults, auditability path

### Constraints
- **NOW (PoC):** frontend-only on Vercel, HTML5 assets, no backend
- **NEXT (MVP):** add backend + realtime + auth + persistence without rewriting UI
- **Regulated domain adjacency:** adopt “compliance-ready” patterns early, avoid PHI/PII expansion

---

## System context (C4 — L1) — MVP target

```mermaid
flowchart LR
  userS[Surgeon] --> web[LiveSurgery Web App]
  userO[Observer] --> web
  userA[Admin] --> web

  web --> api[Session API]
  web --> rt[Realtime Signaling]
  web --> sfu[Media SFU]
  api --> db[(Postgres)]
  api --> obj[(Object Storage)]
  api --> idp[Identity Provider / Auth]

  sfu --> stun[STUN/TURN]
  sfu --> rec[Recording Worker]
  rec --> obj

  subgraph External
    idp
    obj
    stun
  end
```

---

## Container view (C4 — L2) — MVP target

> Recommended MVP: **Vercel-hosted frontend + managed backend** (or containerized later), and **managed SFU** option to avoid heavy DevOps.

```mermaid
flowchart TB
  subgraph Client
    browser[Browser (React SPA)]
  end

  subgraph Edge
    vercel[Vercel Hosting (Static + Edge config)]
  end

  subgraph Backend
    api[API Service (REST)\nNode.js Runtime]
    ws[Realtime Gateway\n(WebSocket)]
    db[(Postgres)]
    cache[(Redis - optional)]
    obj[(S3-compatible Storage)]
  end

  subgraph Media
    sfu[SFU (LiveKit Server or equivalent)]
    turn[TURN/STUN]
    rec[Recording/Transcode Worker]
  end

  browser --> vercel --> api
  browser --> ws
  browser --> sfu
  sfu --> turn
  sfu --> rec --> obj
  api --> db
  api --> obj
  ws --> api
  sfu --> cache
```

---

## Component view (C4 — L3) — Frontend (PoC core reused in MVP)

```mermaid
flowchart LR
  AppShell --> Router
  AppShell --> RoleProvider
  AppShell --> WorkspacePage

  WorkspacePage --> WorkspaceLayoutEngine
  WorkspacePage --> SourceSidebar
  WorkspacePage --> PanelGrid

  PanelGrid --> VideoPanel
  VideoPanel --> Html5VideoPlayer
  VideoPanel --> PanelControls

  WorkspaceLayoutEngine --> DnD[DnD/Resize Controller]
  WorkspaceLayoutEngine --> LayoutState[Layout State Store]

  SourceSidebar --> SourceCatalog[Video Source Catalog]
  SourceSidebar --> SelectionState[Selected Source State]
```

---

## Key decisions (ADR summary)

| ADR | Decision | Rationale |
|---|---|---|
| 001 | PoC stays frontend-only | Fast iteration, portfolio demo |
| 002 | MVP auth + RBAC | Enables real collaboration safely |
| 003 | SFU-based realtime | Scalability + quality control for multi-party |
| 004 | Recording to object storage | Simple retention + replay path |
| 005 | Deployment staged | Vercel now; add services incrementally |

---

## Technology choices & alternatives

### Realtime media options (MVP)

| Option | Pros | Cons | Fit |
|---|---|---|---|
| **Managed SFU (LiveKit Cloud)** | Lowest ops burden, fast MVP | Cost, vendor reliance | Best for solo-dev MVP |
| **Self-host LiveKit** | More control, portable | Needs infra + TURN | Good next step |
| **mediasoup (build your own signaling)** | Maximum flexibility | High complexity; you own everything | Better for “Future” |

### Auth options (MVP)

| Option | Pros | Cons |
|---|---|---|
| **OIDC provider (Auth0/Keycloak/WorkOS)** | Mature RBAC/SSO | Cost or ops |
| **Auth.js / NextAuth** | Popular in JS ecosystems, clear env secret requirements | Primarily Next.js-oriented; assess fit if staying Vite SPA |
