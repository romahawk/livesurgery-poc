## Scope
This document precisely describes what the **frontend-only PoC** is today.

### NOW (PoC) — Summary
- A single-page React SPA that renders an **OR workspace**
- Videos are **static HTML5 assets** (local or hosted), selectable as “sources”
- Layout is interactive via drag/drop / resizing (client-side only)
- Roles are **simulated personas** for demo/storytelling (not real auth)

---

## Pages / routes (PoC)
> If your PoC currently uses a single route, document it as such.

| Route | Purpose | Notes |
|---|---|---|
| `/` | OR workspace | Core demo experience |
| (optional) `/about` | Project overview | Only if implemented |
| (optional) `/demo` | Guided scenario | Only if implemented |

---

## Core UI components (PoC)

| Component | Responsibility | Data |
|---|---|---|
| `AppShell` | Layout chrome, global UI | Local state |
| `WorkspacePage` | Hosts workspace + sidebar | Local state |
| `SourceSidebar` | Source selection list | Source catalog |
| `PanelGrid` | Renders N panels | Layout state |
| `VideoPanel` | One panel w/ controls | assigned source |
| `Html5VideoPlayer` | `<video>` handling | asset URL, playback |
| `RoleBadge/RoleSwitcher` | Simulated persona gating | `role` enum |

---

## State model (PoC)
**Local-only** (React state / context / store). No persistence.

Suggested minimal shape (conceptual):

```ts
type Role = "SURGEON" | "OBSERVER" | "ADMIN";

type VideoSource = {
  id: string;
  label: string;
  url: string;        // points to HTML5 video asset
  kind: "ASSET";
  thumbnailUrl?: string;
};

type Panel = {
  id: string;
  sourceId?: string;
  rect: { x: number; y: number; w: number; h: number };
  muted?: boolean;
};

type WorkspaceState = {
  role: Role;
  sources: VideoSource[];
  panels: Panel[];
  activePanelId?: string;
};
```

---

## Video asset handling (PoC)
- Uses HTML5 `<video>` elements
- Source switching is done by changing `video.src` / `source` URL
- No streaming protocols (no WebRTC/HLS/DASH)
- Likely constraints:
  - Browser autoplay policies (muted autoplay)
  - Asset size impacts initial load
  - No adaptive bitrate (ABR)

---

## Drag/drop & layout logic (PoC)
- Panels can be moved/resized in the workspace grid/canvas
- Layout changes update the in-memory `panels[].rect`
- No multi-user sync, no server authority, no conflict resolution

> Implementation may use a DnD library or custom pointer handlers; document whichever you use in the repo.

---

## What’s intentionally simulated (PoC)

| Capability | Status | How it’s simulated |
|---|---|---|
| Roles & permissions | Simulated | UI toggles / persona selector |
| Multi-user session | Not real | Single browser instance |
| Streaming | Not real | HTML5 assets |
| Collaboration | Not real | Local state only |
| Persistence | Not real | No backend/storage |
| Compliance controls | Not real | Documentation-only |

---

## Known limitations (PoC)
- No auth; anyone with URL can access
- No persistence; refresh resets state
- No real-time constraints modeled (latency/jitter)
- No audit logs or session history
- Not suitable for clinical workflows
