## PoC deployment (NOW)

### Hosting
- Vercel static hosting for Vite SPA
- Typical flow: connect Git repo → preview deploys → production deploy

### Environments
- `development`: local Vite dev server
- `preview`: Vercel preview per PR
- `production`: main branch deployment

---

## MVP deployment options (NEXT)

### Option A (recommended for solo dev): Vercel + managed services
- Frontend: Vercel
- API: serverless (Vercel Functions) or separate managed runtime
- DB: managed Postgres
- Object storage: S3-compatible
- SFU: managed (fastest) or self-host later
- TURN: managed TURN provider or bundled with SFU deployment

### Option B: containerized (portable)
- Frontend: Vercel or static CDN
- API + WS: container services
- SFU + TURN: dedicated nodes
- Best for “Future” enterprise readiness

---

## Config & secrets

### PoC
- mostly none (static assets)

### MVP
| Secret | Purpose |
|---|---|
| `DATABASE_URL` | Postgres connection |
| `OBJECT_STORE_*` | bucket access |
| `AUTH_*` | auth provider keys/secret |
| `SFU_API_KEY/SFU_SECRET` | mint join tokens |
| `WS_JWT_SECRET` | realtime tokens |
| `TURN_*` | if self-managed |

---

## CI/CD outline
- Lint + typecheck + unit tests on PR
- Build preview deploy (Vercel)
- On main merge: production deploy
- Optional: DB migrations gated with manual approval

---

## Deployment diagrams (PoC vs MVP)

```mermaid
flowchart LR
  subgraph POC[NOW: PoC]
    dev1[Browser] --> vercel1[Vercel Static SPA]
    vercel1 --> assets1[Video Assets]
  end

  subgraph MVP[NEXT: MVP]
    dev2[Browser] --> vercel2[Vercel SPA]
    vercel2 --> api2[API Service]
    dev2 --> ws2[Realtime WS]
    dev2 --> sfu2[SFU]
    api2 --> db2[(Postgres)]
    api2 --> obj2[(Object Storage)]
    sfu2 --> obj2
  end
```
