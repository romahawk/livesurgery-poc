## Observability goals (MVP)
- Diagnose join failures quickly (auth vs signaling vs TURN vs SFU)
- Track session health and user experience (latency/jitter proxies)
- Provide portfolio-grade operational maturity without overbuilding

---

## Logging

### What to log
- requestId-correlated API logs
- auth decisions (role, sessionId) without leaking tokens
- session lifecycle events
- realtime connect/disconnect reasons
- recording job lifecycle

### How
- Structured JSON logs
- Redact:
  - tokens
  - raw IPs (or hash with salt if needed)
  - sensitive metadata

---

## Metrics (MVP)

| Area | Metric | Target/SLO (starter) |
|---|---|---|
| Availability | API success rate | 99.5% |
| Realtime | WS connect success | 99% |
| Media | join-to-first-frame | p95 < 3s |
| Media | packet loss (client reported) | < 3% typical |
| Recording | completion success | 99% |

> WebRTC client telemetry is often app-specific; start with lightweight client-side reports.

---

## Tracing
- Distributed tracing for API + WS gateway
- Correlate “join session” across:
  - API join call
  - WS connect
  - SFU token mint

---

## Debug playbook (basics)
1. **User can’t join session**
   - Check API auth logs → role denied vs session missing
2. **WS connected but no sync**
   - Verify room/sessionId mapping and token scopes
3. **Media fails**
   - Check TURN reachability; NAT type
   - Confirm SFU token expiry and room name
4. **Recording missing**
   - Confirm recorder job ran; verify object storage writes
