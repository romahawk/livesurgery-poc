## MVP goals
Deliver a realistic “LiveSurgery session” experience:
- authenticated users join a session
- a publisher shares one or more video streams
- observers subscribe with low latency
- layout/source changes synchronize across users
- session metadata is persisted
- optional recording → archive playback

---

## MVP scope (MoSCoW)

| Must | Should | Could |
|---|---|---|
| Auth (login) + RBAC (Surgeon/Observer/Admin) | Invite links + session lobby | Simple chat |
| Create/join session | Layout persistence | Basic annotations (pointer/marker) |
| Publish/subscribe video via SFU | Recording to object storage | Scene presets |
| Realtime sync for layout/source selection | Archive list & playback | Usage analytics dashboard |
| Session metadata in DB | Admin user management | Export session report |

---

## MVP user journeys

### Surgeon
1. Login
2. Create session (title, privacy, roles)
3. Start publishing camera(s) / media sources
4. Adjust workspace layout; observers see updates
5. Stop session; optionally trigger recording finalization

### Observer
1. Login
2. Join via link or session list
3. Subscribe to streams
4. Follow workspace changes (read-only or limited control)

### Admin
1. Login
2. Manage users + roles
3. View audit-ish activity summary (MVP-lite)
4. Configure retention defaults (non-clinical posture)

---

## Architecture changes from PoC → MVP

| Area | PoC | MVP |
|---|---|---|
| Identity | Simulated | Real AuthN + RBAC |
| State | Local only | Server-authoritative session state + realtime sync |
| Video | HTML5 assets | WebRTC streams via SFU |
| Persistence | None | Postgres + object storage |
| Collaboration | None | WebSocket updates + optimistic UI |
| Observability | None | Structured logs + metrics + basic tracing |

---

## Build sequence plan (milestones / sprints)

### Milestone 1 — Backend foundation
- Create API service skeleton + DB migrations
- Implement Auth + RBAC scaffolding
- Session CRUD + membership model

### Milestone 2 — Realtime collaboration (non-media)
- WebSocket gateway
- Presence + session state sync (layout/source)
- Conflict handling: server timestamps, last-write-wins per field

### Milestone 3 — WebRTC integration
- Integrate SFU (managed first)
- Signaling tokens from API
- Publish/subscribe flows in frontend

### Milestone 4 — Archive & recording (MVP-lite)
- Record stream(s) → object storage
- Archive list + playback (HLS or MP4)
- Retention policy defaults

### Milestone 5 — Hardening & portfolio polish
- Threat model pass, logging, basic SLOs
- Seed data, demo scripts, contributor onboarding
