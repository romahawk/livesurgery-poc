## API style
- REST + JSON
- Bearer auth (JWT) or secure cookie session
- Server-generated IDs (UUID)
- All timestamps are ISO-8601 (UTC)

### Error envelope (consistent)
```json
{
  "error": {
    "code": "SESSION_NOT_FOUND",
    "message": "Session not found",
    "requestId": "req_01HR..."
  }
}
```

### Pagination convention
- Cursor-based preferred for lists
- Query: `?limit=50&cursor=...`
- Response includes `nextCursor`

---

## Auth
> Provider choice is an ADR; endpoints below assume API receives validated identity (JWT) and enforces RBAC.

---

## Sessions

### Create session
`POST /v1/sessions`

Request:
```json
{ "title": "Cholecystectomy demo", "visibility": "PRIVATE" }
```

Response `201`:
```json
{
  "id": "b2c7f7c5-9c43-4c55-8dd0-4c9c3a8dd2a1",
  "title": "Cholecystectomy demo",
  "status": "DRAFT",
  "createdAt": "2026-02-10T12:00:00Z"
}
```

### List sessions (visible to user)
`GET /v1/sessions?limit=20&cursor=...`

Response `200`:
```json
{
  "items": [
    { "id": "...", "title": "...", "status": "LIVE", "updatedAt": "..." }
  ],
  "nextCursor": "eyJvZmZzZXQiOjIwfQ=="
}
```

### Get session
`GET /v1/sessions/{sessionId}`

### Start session
`POST /v1/sessions/{sessionId}/start`

### End session
`POST /v1/sessions/{sessionId}/end`

---

## Participants

### Join session
`POST /v1/sessions/{sessionId}/participants:join`

Response `200`:
```json
{
  "participant": { "userId": "...", "role": "OBSERVER" },
  "realtime": { "wsUrl": "wss://...", "token": "..." },
  "media": { "sfuUrl": "wss://...", "token": "..." }
}
```

### Update participant role (Admin only)
`PATCH /v1/sessions/{sessionId}/participants/{userId}`

Request:
```json
{ "role": "SURGEON" }
```

---

## Layouts

### Get latest layout
`GET /v1/sessions/{sessionId}/layout`

Response:
```json
{
  "version": 12,
  "layout": {
    "panels": [
      { "id": "p1", "rect": { "x": 0, "y": 0, "w": 6, "h": 4 }, "streamId": "s1" }
    ]
  }
}
```

### Publish new layout version
`POST /v1/sessions/{sessionId}/layout`

Request:
```json
{
  "baseVersion": 12,
  "layout": { "panels": [ /* ... */ ] }
}
```

Response:
```json
{ "version": 13 }
```

Conflict:
- `409 LAYOUT_VERSION_CONFLICT` if `baseVersion` is not latest

---

## Archives

### List archives for a session
`GET /v1/sessions/{sessionId}/archives`

### Create archive (trigger recording finalization)
`POST /v1/sessions/{sessionId}/archives`

Request:
```json
{ "mode": "RECORD_LIVE" }
```

Response:
```json
{ "archiveId": "...", "status": "PROCESSING" }
```
